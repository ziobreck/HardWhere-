<?php
$elencoFornitori = "ElencoFornitori.txt";

$ElencoHandler = fopen($elencoFornitori, 'r');
$lettura = fread($ElencoHandler, filesize($elencoFornitori));
$scrittura = $_REQUEST['nuovoFornitore'];
$NuovoFornitore = $scrittura;
fwrite($ElencoHandler, $NuovoFornitore);
fclose($ElencoHandler);
echo $lettura;

?>