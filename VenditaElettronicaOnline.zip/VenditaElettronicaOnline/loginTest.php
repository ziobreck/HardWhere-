<?php
$username = $_REQUEST['user'];
$password = $_REQUEST['password'];

if($username == "admin" and $password == "password")
	include "admin.html";
else
	include "retry.html";
?>