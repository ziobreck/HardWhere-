<?php
$elencoClienti = "ElencoClienti.txt";

$ClientiHandler = fopen($elencoClientiù, 'r');
$lettura = fread($ClientiHandlerHandler, filesize($elencoClienti));
$scrittura = $_REQUEST['nuovoCliente'];
$NuovoCliente = $scrittura;
fwrite($ClientiHandler, $NuovoCliente);
fclose($ClientiHandler);
echo $lettura;

?>